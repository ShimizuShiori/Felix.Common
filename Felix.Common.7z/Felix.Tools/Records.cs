﻿namespace Felix.Tools
{
	public record ToolInfo(ToolAttribute Attribute, Type Type);
}
