﻿namespace Felix.Tools.Tools
{
	interface ITool
	{
		void Start();
	}
}
