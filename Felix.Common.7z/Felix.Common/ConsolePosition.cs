﻿namespace Felix.Common
{
	record ConsolePosition(int Top, int Left);
}
